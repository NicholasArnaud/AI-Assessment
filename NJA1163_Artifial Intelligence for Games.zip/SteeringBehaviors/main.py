'''EXAMPLE MAIN'''
from concretegame import ConcreteGame
def main():
    '''main execution func'''
    game = ConcreteGame("Concrete Game")
    # make gameobjects to participate in game
    game.run()

if __name__ == "__main__":
    main()
    